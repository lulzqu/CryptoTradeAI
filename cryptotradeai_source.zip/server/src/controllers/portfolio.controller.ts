import { Request, Response, NextFunction } from 'express';
import { asyncHandler } from '../middleware/asyncHandler';
import { ErrorResponse } from '../utils/errorResponse';
import Position, { IPosition } from '../models/Position';
import { PositionStatus } from '../types';
import mongoose from 'mongoose';
import { MEXCService } from '../services/mexc';
import { TradingService } from '../services/trading';
import { RiskManagementService } from '../services/riskManagement';
import { AppError } from '../middleware/errorHandler';

/**
 * @desc    Lấy tất cả vị thế của người dùng
 * @route   GET /api/portfolio/positions
 * @access  Private
 */
export const getPositions = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { status, symbol, startDate, endDate, sort = '-createdAt' } = req.query;
  
  // Tạo query
  let query: any = { user: req.user.id };
  
  // Lọc theo trạng thái
  if (status) {
    query.status = status;
  }
  
  // Lọc theo cặp giao dịch
  if (symbol) {
    query.symbol = symbol;
  }
  
  // Lọc theo khoảng thời gian
  if (startDate && endDate) {
    query.openDate = {
      $gte: new Date(startDate as string),
      $lte: new Date(endDate as string)
    };
  } else if (startDate) {
    query.openDate = { $gte: new Date(startDate as string) };
  } else if (endDate) {
    query.openDate = { $lte: new Date(endDate as string) };
  }
  
  // Thực thi query
  const positions = await Position.find(query).sort(sort as string);
  
  res.status(200).json({
    success: true,
    count: positions.length,
    data: positions
  });
});

/**
 * @desc    Lấy tất cả vị thế đang mở của người dùng
 * @route   GET /api/portfolio/positions/open
 * @access  Private
 */
export const getOpenPositions = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const positions = await Position.find({ 
    user: req.user.id,
    status: PositionStatus.OPEN
  }).sort({ createdAt: -1 });

  res.status(200).json({
    success: true,
    count: positions.length,
    data: positions
  });
});

/**
 * @desc    Lấy tất cả vị thế đã đóng của người dùng
 * @route   GET /api/portfolio/positions/closed
 * @access  Private
 */
export const getClosedPositions = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const positions = await Position.find({
    user: req.user.id,
    status: { $in: [PositionStatus.CLOSED, PositionStatus.LIQUIDATED] }
  }).sort({ exitTime: -1 });

  res.status(200).json({
    success: true,
    count: positions.length,
    data: positions
  });
});

/**
 * @desc    Lấy thông tin một vị thế
 * @route   GET /api/portfolio/positions/:id
 * @access  Private
 */
export const getPosition = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const position = await Position.findById(req.params.id);
  
  if (!position) {
    return next(new AppError(404, 'Không tìm thấy vị thế'));
  }
  
  // Kiểm tra quyền sở hữu
  if (position.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền truy cập vị thế này'));
  }
  
  res.status(200).json({
    success: true,
    data: position
  });
});

/**
 * @desc    Tạo vị thế mới
 * @route   POST /api/portfolio/positions
 * @access  Private
 */
export const createPosition = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  req.body.user = req.user.id;
  
  // Kiểm tra rủi ro
  const riskManagementService = RiskManagementService.getInstance();
  const isValid = await riskManagementService.validatePosition(req.body);
  
  if (!isValid) {
    return next(new AppError(400, 'Vị thế không hợp lệ hoặc có rủi ro cao'));
  }
  
  // Thực hiện giao dịch
  const tradingService = TradingService.getInstance();
  const result = await tradingService.executeOrder({
    userId: req.user.id,
    symbol: req.body.symbol,
    side: req.body.side,
    type: 'MARKET',
    quantity: req.body.quantity
  });
  
  // Tạo vị thế
  const position = await Position.create({
    ...req.body,
    entryPrice: result.price
  });
  
  res.status(201).json({
    success: true,
    data: position
  });
});

/**
 * @desc    Cập nhật vị thế
 * @route   PUT /api/portfolio/positions/:id
 * @access  Private
 */
export const updatePosition = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  let position = await Position.findById(req.params.id);
  
  if (!position) {
    return next(new AppError(404, 'Không tìm thấy vị thế'));
  }
  
  // Kiểm tra quyền sở hữu
  if (position.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền cập nhật vị thế này'));
  }
  
  // Không cho phép cập nhật một số trường
  const protectedFields = ['user', 'entryPrice', 'status', 'closeDate', 'closingPrice', 'profit'];
  for (const field of protectedFields) {
    if (field in req.body) {
      delete req.body[field];
    }
  }
  
  // Cập nhật vị thế
  position = await Position.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
      new: true,
      runValidators: true
    }
  );
  
  res.status(200).json({
    success: true,
    data: position
  });
});

/**
 * @desc    Đóng vị thế
 * @route   POST /api/portfolio/positions/:id/close
 * @access  Private
 */
export const closePosition = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const position = await Position.findById(req.params.id);
  
  if (!position) {
    return next(new AppError(404, 'Không tìm thấy vị thế'));
  }
  
  // Kiểm tra quyền sở hữu
  if (position.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền đóng vị thế này'));
  }
  
  // Kiểm tra nếu vị thế đã đóng
  if (position.status === 'CLOSED') {
    return next(new AppError(400, 'Vị thế này đã được đóng'));
  }
  
  // Đóng vị thế
  const tradingService = TradingService.getInstance();
  const result = await tradingService.closePosition(position.id, req.user.id);
  
  res.status(200).json({
    success: true,
    data: result
  });
});

/**
 * @desc    Xóa vị thế
 * @route   DELETE /api/portfolio/positions/:id
 * @access  Private
 */
export const deletePosition = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const position = await Position.findById(req.params.id);
  
  if (!position) {
    return next(new AppError(404, 'Không tìm thấy vị thế'));
  }
  
  // Kiểm tra quyền sở hữu
  if (position.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền xóa vị thế này'));
  }
  
  // Chỉ cho phép xóa vị thế đã đóng
  if (position.status === 'OPEN') {
    return next(new AppError(400, 'Không thể xóa vị thế đang mở. Hãy đóng vị thế trước.'));
  }
  
  await position.remove();
  
  res.status(200).json({
    success: true,
    data: {}
  });
});

/**
 * @desc    Lấy thống kê danh mục đầu tư
 * @route   GET /api/portfolio/stats
 * @access  Private
 */
export const getPortfolioStats = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  // Tổng số vị thế
  const totalPositions = await Position.countDocuments({ user: req.user.id });
  
  // Vị thế đang mở
  const openPositions = await Position.countDocuments({ 
    user: req.user.id,
    status: 'OPEN'
  });
  
  // Vị thế đã đóng
  const closedPositions = await Position.countDocuments({ 
    user: req.user.id,
    status: 'CLOSED'
  });
  
  // Tổng lợi nhuận/lỗ
  const profitResult = await Position.aggregate([
    { 
      $match: { 
        user: req.user._id,
        status: 'CLOSED'
      } 
    },
    {
      $group: {
        _id: null,
        totalProfit: { $sum: '$profit' }
      }
    }
  ]);
  
  const totalProfit = profitResult.length > 0 ? profitResult[0].totalProfit : 0;
  
  // Thắng/thua
  const winPositions = await Position.countDocuments({ 
    user: req.user.id,
    status: 'CLOSED',
    profit: { $gt: 0 }
  });
  
  const lossPositions = await Position.countDocuments({ 
    user: req.user.id,
    status: 'CLOSED',
    profit: { $lte: 0 }
  });
  
  // Tỷ lệ thắng
  const winRate = closedPositions > 0 ? (winPositions / closedPositions) * 100 : 0;
  
  // Lấy số dư tài khoản
  const mexcService = MEXCService.getInstance();
  const balances = await mexcService.getAccountInfo();
  
  res.status(200).json({
    success: true,
    data: {
      totalPositions,
      openPositions,
      closedPositions,
      totalProfit,
      winPositions,
      lossPositions,
      winRate,
      balances
    }
  });
});

/**
 * @desc    Lấy lịch sử giao dịch
 * @route   GET /api/portfolio/history
 * @access  Private
 */
export const getTradeHistory = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { symbol, startDate, endDate, limit = 50, page = 1 } = req.query;
  
  // Tạo query
  let query: any = { 
    user: req.user.id,
    status: 'CLOSED'
  };
  
  // Lọc theo cặp giao dịch
  if (symbol) {
    query.symbol = symbol;
  }
  
  // Lọc theo khoảng thời gian
  if (startDate && endDate) {
    query.closeDate = {
      $gte: new Date(startDate as string),
      $lte: new Date(endDate as string)
    };
  } else if (startDate) {
    query.closeDate = { $gte: new Date(startDate as string) };
  } else if (endDate) {
    query.closeDate = { $lte: new Date(endDate as string) };
  }
  
  // Phân trang
  const pageSize = parseInt(limit as string);
  const skip = (parseInt(page as string) - 1) * pageSize;
  
  // Thực thi query
  const trades = await Position.find(query)
    .sort('-closeDate')
    .skip(skip)
    .limit(pageSize);
  
  // Tổng số kết quả
  const total = await Position.countDocuments(query);
  
  res.status(200).json({
    success: true,
    count: trades.length,
    pagination: {
      total,
      page: parseInt(page as string),
      pages: Math.ceil(total / pageSize)
    },
    data: trades
  });
}); 