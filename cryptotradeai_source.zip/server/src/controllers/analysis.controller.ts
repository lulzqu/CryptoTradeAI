import { Request, Response, NextFunction } from 'express';
import { asyncHandler } from '../middleware/asyncHandler';
import { ErrorResponse } from '../utils/errorResponse';
import { Sentiment, SignalType } from '../types';
import { TechnicalAnalysisService } from '../services/technicalAnalysis';
import { PatternRecognitionService } from '../services/patternRecognition';
import { Signal } from '../models/Signal';
import { Strategy } from '../models/Strategy';
import { Backtest } from '../models/Backtest';
import { AppError } from '../middleware/errorHandler';

/**
 * @desc    Lấy phân tích kỹ thuật cho một mã coin cụ thể
 * @route   GET /api/analysis/coin/:symbol
 * @access  Public
 */
export const getCoinAnalysis = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { symbol } = req.params;
  const { timeframe = '1h' } = req.query;
  
  try {
    // Mock data cho MVP - sẽ được thay thế bằng phân tích thực tế
    const analysis = {
      symbol: symbol.toUpperCase(),
      timeframe,
      timestamp: new Date().toISOString(),
      indicators: {
        rsi: {
          value: Math.random() * 100,
          interpretation: Math.random() > 0.5 ? 'Oversold' : 'Overbought',
          signal: Math.random() > 0.6 ? 'Buy' : 'Sell'
        },
        macd: {
          value: Math.random() * 100 - 50,
          signal: Math.random() * 100 - 50,
          histogram: Math.random() * 20 - 10,
          interpretation: Math.random() > 0.5 ? 'Bullish' : 'Bearish',
          signal: Math.random() > 0.6 ? 'Buy' : 'Sell'
        },
        bb: {
          upper: Math.random() * 1000 + 500,
          middle: Math.random() * 1000,
          lower: Math.random() * 500,
          width: Math.random() * 5,
          interpretation: Math.random() > 0.5 ? 'Expanding' : 'Contracting',
          signal: Math.random() > 0.6 ? 'Buy' : 'Sell'
        },
        ema: {
          ema9: Math.random() * 1000,
          ema20: Math.random() * 1000,
          ema50: Math.random() * 1000,
          ema200: Math.random() * 1000,
          interpretation: Math.random() > 0.5 ? 'Uptrend' : 'Downtrend',
          signal: Math.random() > 0.6 ? 'Buy' : 'Sell'
        }
      },
      patterns: {
        identified: Math.random() > 0.7,
        type: Math.random() > 0.5 ? 'Bullish' : 'Bearish',
        name: ['Double Bottom', 'Head and Shoulders', 'Cup and Handle', 'Triangle', 'Flag'][Math.floor(Math.random() * 5)],
        confidence: Math.random() * 100
      },
      support_resistance: {
        supports: [Math.random() * 900, Math.random() * 800, Math.random() * 700],
        resistances: [Math.random() * 1100, Math.random() * 1200, Math.random() * 1300]
      },
      summary: {
        sentiment: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH,
        strength: Math.floor(Math.random() * 10) + 1,
        recommendation: Math.random() > 0.6 ? 'Strong Buy' : Math.random() > 0.3 ? 'Buy' : 'Sell'
      }
    };
    
    res.status(200).json({
      success: true,
      data: analysis
    });
  } catch (error) {
    return next(new ErrorResponse(`Không thể lấy phân tích cho ${symbol}`, 500));
  }
});

/**
 * @desc    Lấy tổng quan thị trường
 * @route   GET /api/analysis/market-overview
 * @access  Public
 */
export const getMarketOverview = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Mock data cho MVP - sẽ được thay thế bằng phân tích thực tế
    const marketAnalysis = {
      timestamp: new Date().toISOString(),
      btcDominance: {
        value: 40 + Math.random() * 20,
        change24h: Math.random() * 2 - 1
      },
      globalMarketCap: {
        value: 1 + Math.random() * 2,
        change24h: Math.random() * 10 - 5
      },
      sentiment: {
        overall: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH,
        fearGreedIndex: Math.floor(Math.random() * 100)
      },
      topMovers: {
        gainers: [
          { symbol: 'SOL/USDT', change24h: 15 + Math.random() * 10 },
          { symbol: 'AVAX/USDT', change24h: 10 + Math.random() * 10 },
          { symbol: 'ARB/USDT', change24h: 5 + Math.random() * 10 }
        ],
        losers: [
          { symbol: 'DOGE/USDT', change24h: -(5 + Math.random() * 10) },
          { symbol: 'LTC/USDT', change24h: -(3 + Math.random() * 10) },
          { symbol: 'XRP/USDT', change24h: -(1 + Math.random() * 10) }
        ]
      },
      sectorPerformance: [
        { name: 'DeFi', change24h: Math.random() * 20 - 10 },
        { name: 'Layer 1', change24h: Math.random() * 20 - 10 },
        { name: 'Layer 2', change24h: Math.random() * 20 - 10 },
        { name: 'Meme', change24h: Math.random() * 20 - 10 },
        { name: 'AI', change24h: Math.random() * 20 - 10 }
      ],
      marketCycles: {
        btc: Math.random() > 0.5 ? 'Accumulation' : Math.random() > 0.5 ? 'Bull' : 'Bear',
        alts: Math.random() > 0.5 ? 'Accumulation' : Math.random() > 0.5 ? 'Bull' : 'Bear'
      }
    };
    
    res.status(200).json({
      success: true,
      data: marketAnalysis
    });
  } catch (error) {
    return next(new ErrorResponse('Không thể lấy tổng quan thị trường', 500));
  }
});

/**
 * @desc    Lấy các dự báo AI cho một mã coin cụ thể
 * @route   GET /api/analysis/ai-predictions/:symbol
 * @access  Private
 */
export const getAIPredictions = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { symbol } = req.params;
  const { timeframe = '1d' } = req.query;
  
  try {
    // Mock data cho MVP - sẽ được thay thế bằng phân tích AI thực tế
    const aiPredictions = {
      symbol: symbol.toUpperCase(),
      timeframe,
      timestamp: new Date().toISOString(),
      pricePredictions: {
        '24h': {
          min: Math.random() * 900,
          max: Math.random() * 1100 + 1000,
          most_likely: Math.random() * 1000 + 500,
          confidence: Math.random() * 40 + 60
        },
        '7d': {
          min: Math.random() * 800,
          max: Math.random() * 1200 + 1000,
          most_likely: Math.random() * 1000 + 500,
          confidence: Math.random() * 30 + 50
        },
        '30d': {
          min: Math.random() * 700,
          max: Math.random() * 1300 + 1000,
          most_likely: Math.random() * 1000 + 500,
          confidence: Math.random() * 20 + 40
        }
      },
      sentiment: {
        value: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH,
        strength: Math.floor(Math.random() * 10) + 1,
        sources: {
          social_media: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH,
          news: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH,
          on_chain: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH
        }
      },
      pattern_recognition: {
        current_pattern: ['Double Bottom', 'Head and Shoulders', 'Cup and Handle', 'Triangle', 'Flag'][Math.floor(Math.random() * 5)],
        confidence: Math.random() * 100,
        projected_outcome: Math.random() > 0.6 ? 'Bullish Breakout' : 'Bearish Breakdown',
        historical_success_rate: Math.random() * 100
      },
      volatility_prediction: {
        expected_volatility: Math.random() * 20,
        compared_to_avg: Math.random() > 0.5 ? 'Higher' : 'Lower'
      },
      model_metrics: {
        accuracy: Math.random() * 40 + 60,
        recall: Math.random() * 40 + 60,
        precision: Math.random() * 40 + 60,
        f1_score: Math.random() * 40 + 60
      }
    };
    
    res.status(200).json({
      success: true,
      data: aiPredictions
    });
  } catch (error) {
    return next(new ErrorResponse(`Không thể lấy dự báo AI cho ${symbol}`, 500));
  }
});

/**
 * @desc    Lấy các tín hiệu giao dịch
 * @route   GET /api/analysis/signals
 * @access  Private
 */
export const getTradingSignals = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { limit = 10 } = req.query;
  
  try {
    // Mock data cho MVP - sẽ được thay thế bằng phân tích thực tế
    const signals = [];
    const signalTypes = Object.values(SignalType);
    const timeframes = ['15m', '1h', '4h', '1d'];
    
    for (let i = 0; i < Number(limit); i++) {
      signals.push({
        id: `signal-${i + 1}`,
        symbol: ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT', 'XRP/USDT'][Math.floor(Math.random() * 5)],
        type: signalTypes[Math.floor(Math.random() * signalTypes.length)],
        timeframe: timeframes[Math.floor(Math.random() * timeframes.length)],
        entryPrice: Math.random() * 10000,
        stopLoss: Math.random() * 9000,
        takeProfits: [
          Math.random() * 11000,
          Math.random() * 12000,
          Math.random() * 13000
        ],
        riskRewardRatio: (1 + Math.random() * 2).toFixed(1) + ':1',
        confidence: Math.random() * 100,
        sentiment: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH,
        timestamp: new Date(Date.now() - Math.random() * 86400000).toISOString()
      });
    }
    
    res.status(200).json({
      success: true,
      count: signals.length,
      data: signals
    });
  } catch (error) {
    return next(new ErrorResponse('Không thể lấy tín hiệu giao dịch', 500));
  }
});

/**
 * @desc    Lấy thiết lập giao dịch đề xuất cho một mã coin
 * @route   GET /api/analysis/trade-setup/:symbol
 * @access  Private
 */
export const getTradeSetup = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { symbol } = req.params;
  
  try {
    // Mock data cho MVP - sẽ được thay thế bằng phân tích thực tế
    const tradeSetup = {
      symbol: symbol.toUpperCase(),
      timestamp: new Date().toISOString(),
      setup: {
        type: Math.random() > 0.5 ? 'LONG' : 'SHORT',
        sentiment: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH,
        pattern: ['Breakout', 'Reversal', 'Trend Continuation', 'Range Play'][Math.floor(Math.random() * 4)],
        timeframe: ['1h', '4h', '1d'][Math.floor(Math.random() * 3)]
      },
      entry: {
        price: Math.random() * 10000,
        zone: {
          min: Math.random() * 9500,
          max: Math.random() * 10500 + 9500
        },
        rationale: 'Dựa trên mức hỗ trợ/kháng cự và phân kỳ RSI'
      },
      stopLoss: {
        price: Math.random() * 9000,
        percentage: Math.random() * 5 + 2,
        rationale: 'Dưới mức hỗ trợ quan trọng gần nhất'
      },
      takeProfits: [
        {
          level: 1,
          price: Math.random() * 11000,
          percentage: Math.random() * 10 + 5,
          rationale: 'Kháng cự cấp 1'
        },
        {
          level: 2,
          price: Math.random() * 12000 + 11000,
          percentage: Math.random() * 15 + 10,
          rationale: 'Kháng cự cấp 2'
        },
        {
          level: 3,
          price: Math.random() * 13000 + 12000,
          percentage: Math.random() * 20 + 15,
          rationale: 'Kháng cự cấp 3'
        }
      ],
      metrics: {
        riskRewardRatio: (1 + Math.random() * 3).toFixed(1) + ':1',
        winProbability: Math.random() * 40 + 60,
        expectedValue: Math.random() * 40 + 10
      },
      position: {
        recommendedSize: Math.random() * 5 + 1,
        maxLeverage: Math.floor(Math.random() * 10) + 1,
        maxRiskPercentage: Math.random() * 2 + 0.5
      },
      additional: {
        keyLevels: {
          supports: [Math.random() * 9000, Math.random() * 8000, Math.random() * 7000],
          resistances: [Math.random() * 11000, Math.random() * 12000, Math.random() * 13000]
        },
        marketConditions: Math.random() > 0.5 ? 'Trending' : 'Ranging',
        notes: 'Theo dõi khối lượng giao dịch khi tiếp cận vùng giá entry'
      }
    };
    
    res.status(200).json({
      success: true,
      data: tradeSetup
    });
  } catch (error) {
    return next(new ErrorResponse(`Không thể lấy thiết lập giao dịch cho ${symbol}`, 500));
  }
});

/**
 * @desc    Tạo phân tích tùy chỉnh
 * @route   POST /api/analysis/custom
 * @access  Private
 */
export const createCustomAnalysis = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { symbol, indicators, timeframe, additionalParameters } = req.body;
  
  if (!symbol) {
    return next(new ErrorResponse('Vui lòng cung cấp mã giao dịch (symbol)', 400));
  }
  
  try {
    // Mock data cho MVP - sẽ được thay thế bằng phân tích thực tế
    const customAnalysis = {
      symbol: symbol.toUpperCase(),
      timeframe: timeframe || '1d',
      timestamp: new Date().toISOString(),
      requested_by: req.user.id,
      indicators: indicators || ['RSI', 'MACD', 'Bollinger Bands'],
      results: {
        summary: {
          sentiment: Math.random() > 0.5 ? Sentiment.BULLISH : Sentiment.BEARISH,
          strength: Math.floor(Math.random() * 10) + 1,
          recommendation: Math.random() > 0.6 ? 'Strong Buy' : Math.random() > 0.3 ? 'Buy' : 'Sell'
        },
        details: {
          price_action: {
            trend: Math.random() > 0.5 ? 'Uptrend' : 'Downtrend',
            momentum: Math.random() > 0.5 ? 'Strong' : 'Weak',
            volatility: Math.random() > 0.5 ? 'High' : 'Low'
          },
          patterns: {
            identified: Math.random() > 0.7,
            type: Math.random() > 0.5 ? 'Bullish' : 'Bearish',
            name: ['Double Bottom', 'Head and Shoulders', 'Cup and Handle', 'Triangle', 'Flag'][Math.floor(Math.random() * 5)],
            confidence: Math.random() * 100
          }
        }
      }
    };
    
    res.status(200).json({
      success: true,
      data: customAnalysis
    });
  } catch (error) {
    return next(new ErrorResponse('Không thể tạo phân tích tùy chỉnh', 500));
  }
});

// @desc    Lấy các chỉ báo kỹ thuật cho một cặp giao dịch
// @route   GET /api/analysis/indicators/:symbol
// @access  Public
export const getIndicators = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { symbol } = req.params;
  const { timeframe = '1h' } = req.query;
  
  if (!symbol) {
    return next(new AppError(400, 'Vui lòng cung cấp mã cặp giao dịch'));
  }
  
  const technicalAnalysisService = TechnicalAnalysisService.getInstance();
  const indicators = await technicalAnalysisService.calculateIndicators(symbol, timeframe as string);
  
  res.status(200).json({
    success: true,
    data: indicators
  });
});

// @desc    Lấy các mẫu hình nến cho một cặp giao dịch
// @route   GET /api/analysis/patterns/:symbol
// @access  Public
export const getPatterns = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { symbol } = req.params;
  const { timeframe = '1h' } = req.query;
  
  if (!symbol) {
    return next(new AppError(400, 'Vui lòng cung cấp mã cặp giao dịch'));
  }
  
  const patternRecognitionService = PatternRecognitionService.getInstance();
  const patterns = await patternRecognitionService.detectPatterns(symbol, timeframe as string);
  
  res.status(200).json({
    success: true,
    data: patterns
  });
});

// @desc    Lấy danh sách tín hiệu
// @route   GET /api/analysis/signals
// @access  Public
export const getSignals = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { symbol, status, timeframe, createdBy, limit = 10, sort = '-createdAt' } = req.query;
  
  // Tạo query
  let query: any = {};
  
  // Lọc theo cặp giao dịch
  if (symbol) {
    query.symbol = symbol;
  }
  
  // Lọc theo trạng thái
  if (status) {
    query.status = status;
  }
  
  // Lọc theo khung thời gian
  if (timeframe) {
    query.timeframe = timeframe;
  }
  
  // Lọc theo người tạo
  if (createdBy) {
    query.createdBy = createdBy;
  } else if (req.user) {
    // Nếu người dùng đã đăng nhập, hiển thị tín hiệu hệ thống + tín hiệu của họ
    query.$or = [
      { createdBy: req.user.id },
      { isSystem: true }
    ];
  } else {
    // Nếu chưa đăng nhập, chỉ hiển thị tín hiệu hệ thống
    query.isSystem = true;
  }
  
  // Thực thi query
  const signals = await Signal.find(query)
    .sort(sort as string)
    .limit(parseInt(limit as string));
  
  res.status(200).json({
    success: true,
    count: signals.length,
    data: signals
  });
});

// @desc    Lấy thông tin một tín hiệu
// @route   GET /api/analysis/signals/:id
// @access  Private
export const getSignal = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const signal = await Signal.findById(req.params.id);
  
  if (!signal) {
    return next(new AppError(404, 'Không tìm thấy tín hiệu'));
  }
  
  // Kiểm tra quyền truy cập (nếu không phải tín hiệu hệ thống)
  if (!signal.isSystem && signal.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền truy cập tín hiệu này'));
  }
  
  res.status(200).json({
    success: true,
    data: signal
  });
});

// @desc    Tạo tín hiệu mới
// @route   POST /api/analysis/signals
// @access  Private
export const createSignal = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  req.body.createdBy = req.user.id;
  
  const signal = await Signal.create(req.body);
  
  res.status(201).json({
    success: true,
    data: signal
  });
});

// @desc    Cập nhật tín hiệu
// @route   PUT /api/analysis/signals/:id
// @access  Private
export const updateSignal = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  let signal = await Signal.findById(req.params.id);
  
  if (!signal) {
    return next(new AppError(404, 'Không tìm thấy tín hiệu'));
  }
  
  // Kiểm tra quyền cập nhật
  if (signal.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền cập nhật tín hiệu này'));
  }
  
  // Không cho phép cập nhật các trường quan trọng
  if (req.body.createdBy) delete req.body.createdBy;
  if (req.body.isSystem) delete req.body.isSystem;
  
  signal = await Signal.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });
  
  res.status(200).json({
    success: true,
    data: signal
  });
});

// @desc    Xóa tín hiệu
// @route   DELETE /api/analysis/signals/:id
// @access  Private
export const deleteSignal = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const signal = await Signal.findById(req.params.id);
  
  if (!signal) {
    return next(new AppError(404, 'Không tìm thấy tín hiệu'));
  }
  
  // Kiểm tra quyền xóa
  if (signal.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền xóa tín hiệu này'));
  }
  
  // Không cho phép xóa tín hiệu hệ thống
  if (signal.isSystem && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không thể xóa tín hiệu hệ thống'));
  }
  
  await signal.remove();
  
  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Lấy danh sách chiến lược
// @route   GET /api/analysis/strategies
// @access  Private
export const getStrategies = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { isSystem } = req.query;
  
  // Tạo query
  let query: any = {
    $or: [
      { userId: req.user.id },
      { isSystem: true }
    ]
  };
  
  // Lọc theo loại (hệ thống/cá nhân)
  if (isSystem !== undefined) {
    if (isSystem === 'true') {
      query = { isSystem: true };
    } else {
      query = { userId: req.user.id };
    }
  }
  
  const strategies = await Strategy.find(query).sort('-updatedAt');
  
  res.status(200).json({
    success: true,
    count: strategies.length,
    data: strategies
  });
});

// @desc    Lấy thông tin một chiến lược
// @route   GET /api/analysis/strategies/:id
// @access  Private
export const getStrategy = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const strategy = await Strategy.findById(req.params.id);
  
  if (!strategy) {
    return next(new AppError(404, 'Không tìm thấy chiến lược'));
  }
  
  // Kiểm tra quyền truy cập (nếu không phải chiến lược hệ thống)
  if (!strategy.isSystem && strategy.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền truy cập chiến lược này'));
  }
  
  res.status(200).json({
    success: true,
    data: strategy
  });
});

// @desc    Tạo chiến lược mới
// @route   POST /api/analysis/strategies
// @access  Private
export const createStrategy = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  req.body.userId = req.user.id;
  
  // Kiểm tra tên chiến lược đã tồn tại chưa
  const existingStrategy = await Strategy.findOne({
    name: req.body.name,
    $or: [
      { userId: req.user.id },
      { isSystem: true }
    ]
  });
  
  if (existingStrategy) {
    return next(new AppError(400, 'Tên chiến lược đã tồn tại'));
  }
  
  const strategy = await Strategy.create(req.body);
  
  res.status(201).json({
    success: true,
    data: strategy
  });
});

// @desc    Cập nhật chiến lược
// @route   PUT /api/analysis/strategies/:id
// @access  Private
export const updateStrategy = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  let strategy = await Strategy.findById(req.params.id);
  
  if (!strategy) {
    return next(new AppError(404, 'Không tìm thấy chiến lược'));
  }
  
  // Kiểm tra quyền cập nhật
  if (strategy.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền cập nhật chiến lược này'));
  }
  
  // Không cho phép cập nhật các trường quan trọng
  if (req.body.userId) delete req.body.userId;
  if (req.body.isSystem) delete req.body.isSystem;
  
  strategy = await Strategy.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });
  
  res.status(200).json({
    success: true,
    data: strategy
  });
});

// @desc    Xóa chiến lược
// @route   DELETE /api/analysis/strategies/:id
// @access  Private
export const deleteStrategy = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const strategy = await Strategy.findById(req.params.id);
  
  if (!strategy) {
    return next(new AppError(404, 'Không tìm thấy chiến lược'));
  }
  
  // Kiểm tra quyền xóa
  if (strategy.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền xóa chiến lược này'));
  }
  
  // Không cho phép xóa chiến lược hệ thống
  if (strategy.isSystem && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không thể xóa chiến lược hệ thống'));
  }
  
  await strategy.remove();
  
  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Chạy backtest
// @route   POST /api/analysis/backtest
// @access  Private
export const runBacktest = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { strategyId, symbol, timeframe, startDate, endDate, initialBalance } = req.body;
  
  // Kiểm tra thông tin đầu vào
  if (!strategyId || !symbol || !timeframe || !startDate || !endDate || !initialBalance) {
    return next(new AppError(400, 'Vui lòng cung cấp đầy đủ thông tin cho backtest'));
  }
  
  // Kiểm tra chiến lược tồn tại
  const strategy = await Strategy.findById(strategyId);
  
  if (!strategy) {
    return next(new AppError(404, 'Không tìm thấy chiến lược'));
  }
  
  // Kiểm tra quyền truy cập chiến lược
  if (!strategy.isSystem && strategy.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền sử dụng chiến lược này'));
  }
  
  // TODO: Thực hiện backtest
  
  // Tạm thời tạo một kết quả backtest mẫu
  const backtest = await Backtest.create({
    userId: req.user.id,
    strategyId,
    symbol,
    timeframe,
    startDate: new Date(startDate),
    endDate: new Date(endDate),
    initialBalance,
    finalBalance: initialBalance * 1.1, // Giả sử lợi nhuận 10%
    profit: initialBalance * 0.1,
    profitPercentage: 10,
    trades: [],
    metrics: {
      totalTrades: 10,
      winningTrades: 6,
      losingTrades: 4,
      winRate: 60,
      profitFactor: 1.5,
      maxDrawdown: initialBalance * 0.05,
      maxDrawdownPercentage: 5,
      averageProfit: initialBalance * 0.02,
      averageLoss: initialBalance * 0.01,
      averageTrade: initialBalance * 0.01,
      sharpeRatio: 1.2,
      sortinoRatio: 1.5
    },
    parameters: req.body.parameters || {}
  });
  
  res.status(201).json({
    success: true,
    data: backtest
  });
});

// @desc    Lấy danh sách backtest
// @route   GET /api/analysis/backtests
// @access  Private
export const getBacktests = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { strategyId, symbol, timeframe, sort = '-createdAt' } = req.query;
  
  // Tạo query
  let query: any = { userId: req.user.id };
  
  // Lọc theo chiến lược
  if (strategyId) {
    query.strategyId = strategyId;
  }
  
  // Lọc theo cặp giao dịch
  if (symbol) {
    query.symbol = symbol;
  }
  
  // Lọc theo khung thời gian
  if (timeframe) {
    query.timeframe = timeframe;
  }
  
  const backtests = await Backtest.find(query)
    .sort(sort as string)
    .populate('strategyId', 'name');
  
  res.status(200).json({
    success: true,
    count: backtests.length,
    data: backtests
  });
});

// @desc    Lấy thông tin một backtest
// @route   GET /api/analysis/backtests/:id
// @access  Private
export const getBacktest = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const backtest = await Backtest.findById(req.params.id).populate('strategyId', 'name');
  
  if (!backtest) {
    return next(new AppError(404, 'Không tìm thấy backtest'));
  }
  
  // Kiểm tra quyền truy cập
  if (backtest.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError(403, 'Không có quyền truy cập backtest này'));
  }
  
  res.status(200).json({
    success: true,
    data: backtest
  });
}); 