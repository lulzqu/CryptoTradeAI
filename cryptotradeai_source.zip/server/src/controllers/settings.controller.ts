import { Request, Response, NextFunction } from 'express';
import { User } from '../models/User';
import { AppError } from '../middleware/errorHandler';
import { asyncHandler } from '../middleware/errorHandler';

// @desc    Lấy cài đặt người dùng
// @route   GET /api/settings/user
// @access  Private
export const getUserSettings = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const user = await User.findById(req.user.id).select('-password');
  
  if (!user) {
    return next(new AppError(404, 'Không tìm thấy người dùng'));
  }
  
  res.status(200).json({
    success: true,
    data: user.settings
  });
});

// @desc    Cập nhật cài đặt người dùng
// @route   PUT /api/settings/user
// @access  Private
export const updateUserSettings = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { theme, riskLevel } = req.body;
  
  const user = await User.findById(req.user.id);
  
  if (!user) {
    return next(new AppError(404, 'Không tìm thấy người dùng'));
  }
  
  // Cập nhật cài đặt
  if (theme) user.settings.theme = theme;
  if (riskLevel) user.settings.riskLevel = riskLevel;
  
  await user.save();
  
  res.status(200).json({
    success: true,
    data: user.settings
  });
});

// @desc    Lấy API keys
// @route   GET /api/settings/api-keys
// @access  Private
export const getApiKeys = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const user = await User.findById(req.user.id).select('apiKeys');
  
  if (!user) {
    return next(new AppError(404, 'Không tìm thấy người dùng'));
  }
  
  // Trả về cấu trúc API keys không có giá trị thực
  let redactedApiKeys = {};
  
  if (user.apiKeys && user.apiKeys.mexc) {
    redactedApiKeys = {
      mexc: {
        apiKey: user.apiKeys.mexc.apiKey ? '********' : '',
        secretKey: user.apiKeys.mexc.secretKey ? '********' : ''
      }
    };
  }
  
  res.status(200).json({
    success: true,
    data: redactedApiKeys
  });
});

// @desc    Cập nhật API keys
// @route   PUT /api/settings/api-keys
// @access  Private
export const updateApiKeys = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { mexc } = req.body;
  
  if (!mexc || !mexc.apiKey || !mexc.secretKey) {
    return next(new AppError(400, 'Vui lòng cung cấp API key và Secret key'));
  }
  
  const user = await User.findById(req.user.id);
  
  if (!user) {
    return next(new AppError(404, 'Không tìm thấy người dùng'));
  }
  
  // Kiểm tra tính hợp lệ của API keys trước khi lưu
  // TODO: Thực hiện kiểm tra bằng cách gọi một API đơn giản từ MEXC
  
  // Cập nhật API keys
  if (!user.apiKeys) {
    user.apiKeys = {};
  }
  
  user.apiKeys.mexc = {
    apiKey: mexc.apiKey,
    secretKey: mexc.secretKey
  };
  
  await user.save();
  
  res.status(200).json({
    success: true,
    message: 'API keys đã được cập nhật'
  });
});

// @desc    Lấy cài đặt thông báo
// @route   GET /api/settings/notifications
// @access  Private
export const getNotificationSettings = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const user = await User.findById(req.user.id).select('settings.notifications settings.emailAlerts');
  
  if (!user) {
    return next(new AppError(404, 'Không tìm thấy người dùng'));
  }
  
  res.status(200).json({
    success: true,
    data: {
      notifications: user.settings.notifications,
      emailAlerts: user.settings.emailAlerts
    }
  });
});

// @desc    Cập nhật cài đặt thông báo
// @route   PUT /api/settings/notifications
// @access  Private
export const updateNotificationSettings = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const { notifications, emailAlerts } = req.body;
  
  const user = await User.findById(req.user.id);
  
  if (!user) {
    return next(new AppError(404, 'Không tìm thấy người dùng'));
  }
  
  // Cập nhật cài đặt thông báo
  if (notifications !== undefined) user.settings.notifications = notifications;
  if (emailAlerts !== undefined) user.settings.emailAlerts = emailAlerts;
  
  await user.save();
  
  res.status(200).json({
    success: true,
    data: {
      notifications: user.settings.notifications,
      emailAlerts: user.settings.emailAlerts
    }
  });
}); 