import { Position, Trade } from '../types/trading';
import { Signal } from '../types/analysis';
import { RiskManagementService } from './riskManagement';
import { MEXCService } from './mexc';

export class TradingService {
  private static instance: TradingService;
  private riskManagement: RiskManagementService;
  private mexc: MEXCService;

  private constructor() {
    this.riskManagement = RiskManagementService.getInstance();
    this.mexc = MEXCService.getInstance();
  }

  public static getInstance(): TradingService {
    if (!TradingService.instance) {
      TradingService.instance = new TradingService();
    }
    return TradingService.instance;
  }

  public async executeSignal(signal: Signal, userId: string): Promise<Trade> {
    // Kiểm tra rủi ro
    const riskAssessment = await this.riskManagement.assessRisk(signal);
    if (!riskAssessment.approved) {
      throw new Error(`Giao dịch không được phê duyệt: ${riskAssessment.reason}`);
    }

    // Tính toán số lượng
    const quantity = await this.calculateQuantity(signal, userId);

    // Thực hiện giao dịch
    const trade = await this.mexc.executeTrade({
      symbol: signal.symbol,
      side: signal.type,
      quantity,
      price: signal.entryPrice,
      stopLoss: signal.stopLoss,
      takeProfit: signal.takeProfit
    });

    // Lưu giao dịch
    const position: Position = {
      userId,
      symbol: signal.symbol,
      type: signal.type,
      entryPrice: trade.price,
      quantity,
      stopLoss: signal.stopLoss,
      takeProfit: signal.takeProfit,
      status: 'OPEN',
      createdAt: new Date()
    };

    await this.savePosition(position);

    return trade;
  }

  public async closePosition(positionId: string, userId: string): Promise<Trade> {
    const position = await this.getPosition(positionId, userId);
    if (!position) {
      throw new Error('Không tìm thấy vị thế');
    }

    if (position.status !== 'OPEN') {
      throw new Error('Vị thế đã đóng');
    }

    const trade = await this.mexc.executeTrade({
      symbol: position.symbol,
      side: position.type === 'BUY' ? 'SELL' : 'BUY',
      quantity: position.quantity,
      price: 0 // Market price
    });

    position.status = 'CLOSED';
    position.exitPrice = trade.price;
    position.exitTime = new Date();
    position.profit = this.calculateProfit(position);

    await this.updatePosition(position);

    return trade;
  }

  private async calculateQuantity(signal: Signal, userId: string): Promise<number> {
    const balance = await this.mexc.getBalance(userId);
    const riskAmount = balance * 0.01; // 1% rủi ro
    const priceDifference = Math.abs(signal.entryPrice - signal.stopLoss);
    return riskAmount / priceDifference;
  }

  private calculateProfit(position: Position): number {
    if (!position.exitPrice) return 0;
    const priceDifference = position.exitPrice - position.entryPrice;
    return position.type === 'BUY' 
      ? priceDifference * position.quantity
      : -priceDifference * position.quantity;
  }

  private async savePosition(position: Position): Promise<void> {
    // TODO: Lưu vào database
  }

  private async getPosition(positionId: string, userId: string): Promise<Position | null> {
    // TODO: Lấy từ database
    return null;
  }

  private async updatePosition(position: Position): Promise<void> {
    // TODO: Cập nhật vào database
  }
} 