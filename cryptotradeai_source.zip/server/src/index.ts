import express, { Express, Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import helmet from 'helmet';
import morgan from 'morgan';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { config } from './config';
import { WebSocketService } from './services/websocket';
import { errorHandler } from './middleware/errorHandler';
import { requestLogger } from './middleware/requestLogger';
import { authenticate } from './middleware/authenticate';

// Routes
import authRoutes from './routes/auth.routes';
import userRoutes from './routes/user.routes';
import marketRoutes from './routes/market.routes';
import portfolioRoutes from './routes/portfolio.routes';
import analysisRoutes from './routes/analysis.routes';
import settingsRoutes from './routes/settings.routes';

// Middleware
import { logger } from './utils/logger';

// Config
import { PORT, MONGODB_URI, CLIENT_URL, NODE_ENV } from './config';

// Initialize environment variables
dotenv.config();

// Initialize Express app
const app: Express = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: CLIENT_URL,
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(cors({
  origin: CLIENT_URL,
  credentials: true
}));
app.use(helmet());
app.use(morgan('dev'));

// Rate limiting
const limiter = rateLimit(config.security.rateLimit);
app.use(limiter);

// Custom middleware
app.use(requestLogger);

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', authenticate, userRoutes);
app.use('/api/market', marketRoutes);
app.use('/api/portfolio', authenticate, portfolioRoutes);
app.use('/api/analysis', analysisRoutes);
app.use('/api/settings', authenticate, settingsRoutes);

// Base route
app.get('/', (req: Request, res: Response) => {
  res.status(200).json({ message: 'CryptoTradeAI API is running' });
});

// Error handler
app.use(errorHandler);

// 404 route
app.use((req: Request, res: Response) => {
  res.status(404).json({ message: 'Route not found' });
});

// Initialize WebSocket server
import WebSocketServer from './socket';
const webSocketServer = new WebSocketServer(httpServer);

// Socket.IO connection basic handler
io.on('connection', (socket) => {
  console.log('Client connected to basic Socket.IO:', socket.id);

  socket.on('disconnect', () => {
    console.log('Client disconnected from basic Socket.IO:', socket.id);
  });
});

// Start server
const start = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(MONGODB_URI);
    console.log('MongoDB Connected');

    // Start HTTP server
    httpServer.listen(PORT, () => {
      console.log(`Server running in ${NODE_ENV} mode on port ${PORT}`);
    });

    // Initialize WebSocket
    WebSocketService.getInstance(httpServer);
  } catch (error) {
    console.error('Error starting server:', error);
  }
};

start();

// Handle unhandled promise rejections
process.on('unhandledRejection', (err: Error) => {
  console.log(`Error: ${err.message}`);
  // Close server & exit process
  httpServer.close(() => process.exit(1));
});

// Handle shutdown
process.on('SIGINT', () => {
  logger.info('Shutting down server...');
  httpServer.close(() => {
    logger.info('Server closed');
    mongoose.connection.close(false, () => {
      logger.info('MongoDB connection closed');
      process.exit(0);
    });
  });
});

export { app, io, webSocketServer }; 