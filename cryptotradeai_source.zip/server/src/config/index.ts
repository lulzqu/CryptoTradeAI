import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Environment
export const NODE_ENV = process.env.NODE_ENV || 'development';
export const PORT = process.env.PORT || 5000;

// MongoDB
export const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/cryptotradeai';

// CORS
export const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:3000';

// JWT
export const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';
export const JWT_EXPIRE = process.env.JWT_EXPIRE || '30d';
export const JWT_COOKIE_EXPIRE = process.env.JWT_COOKIE_EXPIRE || 30;

// Email
export const EMAIL_SERVICE = process.env.EMAIL_SERVICE || 'gmail';
export const EMAIL_USERNAME = process.env.EMAIL_USERNAME;
export const EMAIL_PASSWORD = process.env.EMAIL_PASSWORD;
export const EMAIL_FROM = process.env.EMAIL_FROM || 'noreply@cryptotradeai.com';

// MEXC API
export const MEXC_API_KEY = process.env.MEXC_API_KEY || '';
export const MEXC_API_SECRET = process.env.MEXC_API_SECRET || '';
export const MEXC_BASE_URL = process.env.MEXC_BASE_URL || 'https://api.mexc.com';

// WebSocket
export const WS_PORT = process.env.WS_PORT || 5001;

// AI Service configuration
export const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
export const HUGGINGFACE_API_KEY = process.env.HUGGINGFACE_API_KEY || '';

// Rate limiting
export const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
export const RATE_LIMIT_MAX = 100; // limit each IP to 100 requests per windowMs

// Security
export const BCRYPT_SALT_ROUNDS = 10; 