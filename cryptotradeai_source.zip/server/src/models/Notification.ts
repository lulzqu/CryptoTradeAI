import mongoose, { Schema, Document } from 'mongoose';

export interface INotification extends Document {
  userId: mongoose.Schema.Types.ObjectId;
  title: string;
  message: string;
  type: 'SIGNAL' | 'TRADE' | 'ALERT' | 'SYSTEM';
  read: boolean;
  data?: Record<string, any>;
  createdAt: Date;
}

const NotificationSchema = new Schema<INotification>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    title: {
      type: String,
      required: true
    },
    message: {
      type: String,
      required: true
    },
    type: {
      type: String,
      enum: ['SIGNAL', 'TRADE', 'ALERT', 'SYSTEM'],
      required: true
    },
    read: {
      type: Boolean,
      default: false
    },
    data: {
      type: Schema.Types.Mixed
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  },
  {
    timestamps: true
  }
);

// Index cho tìm kiếm nhanh
NotificationSchema.index({ userId: 1, read: 1, createdAt: -1 });

// Đặt TTL (Time To Live) để tự động xóa thông báo cũ
// Ví dụ: tự động xóa sau 30 ngày
NotificationSchema.index({ createdAt: 1 }, { expireAfterSeconds: 30 * 24 * 60 * 60 });

// Tạo thông báo cho tín hiệu mới
NotificationSchema.statics.createSignalNotification = async function(
  userId: mongoose.Types.ObjectId,
  signal: any
): Promise<INotification> {
  return this.create({
    userId,
    title: `Tín hiệu mới cho ${signal.symbol}`,
    message: `Tín hiệu ${signal.direction} cho ${signal.symbol} ở mức giá ${signal.entryPrice}`,
    type: 'SIGNAL',
    data: {
      signalId: signal._id,
      symbol: signal.symbol,
      direction: signal.direction,
      entryPrice: signal.entryPrice,
      confidence: signal.confidence
    }
  });
};

// Tạo thông báo cho giao dịch
NotificationSchema.statics.createTradeNotification = async function(
  userId: mongoose.Types.ObjectId,
  trade: any
): Promise<INotification> {
  return this.create({
    userId,
    title: `Giao dịch ${trade.status} - ${trade.symbol}`,
    message: `Giao dịch ${trade.type} ${trade.symbol} đã được ${trade.status === 'COMPLETED' ? 'hoàn thành' : 'cập nhật'}`,
    type: 'TRADE',
    data: {
      tradeId: trade._id,
      symbol: trade.symbol,
      type: trade.type,
      status: trade.status
    }
  });
};

// Tạo thông báo hệ thống
NotificationSchema.statics.createSystemNotification = async function(
  userId: mongoose.Types.ObjectId,
  title: string,
  message: string,
  data?: Record<string, any>
): Promise<INotification> {
  return this.create({
    userId,
    title,
    message,
    type: 'SYSTEM',
    data
  });
};

export const Notification = mongoose.model<
  INotification, 
  mongoose.Model<INotification> & {
    createSignalNotification: (userId: mongoose.Types.ObjectId, signal: any) => Promise<INotification>;
    createTradeNotification: (userId: mongoose.Types.ObjectId, trade: any) => Promise<INotification>;
    createSystemNotification: (userId: mongoose.Types.ObjectId, title: string, message: string, data?: Record<string, any>) => Promise<INotification>;
  }
>('Notification', NotificationSchema); 