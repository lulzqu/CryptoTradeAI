import mongoose, { Schema, Document } from 'mongoose';

export interface IBacktest extends Document {
  userId: mongoose.Schema.Types.ObjectId;
  strategyId: mongoose.Schema.Types.ObjectId;
  symbol: string;
  timeframe: string;
  startDate: Date;
  endDate: Date;
  initialBalance: number;
  finalBalance: number;
  profit: number;
  profitPercentage: number;
  trades: Array<{
    timestamp: Date;
    type: 'BUY' | 'SELL';
    price: number;
    quantity: number;
    profit: number;
    profitPercentage: number;
  }>;
  metrics: {
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    winRate: number;
    profitFactor: number;
    maxDrawdown: number;
    maxDrawdownPercentage: number;
    averageProfit: number;
    averageLoss: number;
    averageTrade: number;
    sharpeRatio: number;
    sortinoRatio: number;
  };
  parameters: Record<string, any>;
  createdAt: Date;
}

const BacktestSchema = new Schema<IBacktest>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    strategyId: {
      type: Schema.Types.ObjectId,
      ref: 'Strategy',
      required: true
    },
    symbol: {
      type: String,
      required: true,
      uppercase: true
    },
    timeframe: {
      type: String,
      required: true,
      enum: ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
    },
    startDate: {
      type: Date,
      required: true
    },
    endDate: {
      type: Date,
      required: true
    },
    initialBalance: {
      type: Number,
      required: true,
      min: 0
    },
    finalBalance: {
      type: Number,
      required: true
    },
    profit: {
      type: Number,
      required: true
    },
    profitPercentage: {
      type: Number,
      required: true
    },
    trades: [{
      timestamp: {
        type: Date,
        required: true
      },
      type: {
        type: String,
        enum: ['BUY', 'SELL'],
        required: true
      },
      price: {
        type: Number,
        required: true
      },
      quantity: {
        type: Number,
        required: true
      },
      profit: {
        type: Number,
        default: 0
      },
      profitPercentage: {
        type: Number,
        default: 0
      }
    }],
    metrics: {
      totalTrades: {
        type: Number,
        required: true
      },
      winningTrades: {
        type: Number,
        required: true
      },
      losingTrades: {
        type: Number,
        required: true
      },
      winRate: {
        type: Number,
        required: true
      },
      profitFactor: {
        type: Number,
        required: true
      },
      maxDrawdown: {
        type: Number,
        required: true
      },
      maxDrawdownPercentage: {
        type: Number,
        required: true
      },
      averageProfit: {
        type: Number,
        required: true
      },
      averageLoss: {
        type: Number,
        required: true
      },
      averageTrade: {
        type: Number,
        required: true
      },
      sharpeRatio: {
        type: Number,
        required: true
      },
      sortinoRatio: {
        type: Number,
        required: true
      }
    },
    parameters: {
      type: Schema.Types.Mixed,
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  },
  {
    timestamps: true
  }
);

// Index cho tìm kiếm nhanh
BacktestSchema.index({ userId: 1, strategyId: 1, createdAt: -1 });
BacktestSchema.index({ symbol: 1, timeframe: 1 });

// Phương thức để tóm tắt kết quả backtest
BacktestSchema.methods.getSummary = function(): Record<string, any> {
  return {
    id: this._id,
    symbol: this.symbol,
    timeframe: this.timeframe,
    startDate: this.startDate,
    endDate: this.endDate,
    profit: this.profit,
    profitPercentage: this.profitPercentage,
    totalTrades: this.metrics.totalTrades,
    winRate: this.metrics.winRate,
    profitFactor: this.metrics.profitFactor,
    maxDrawdown: this.metrics.maxDrawdownPercentage,
    sharpeRatio: this.metrics.sharpeRatio
  };
};

// Tính điểm chất lượng backtest (0-100)
BacktestSchema.methods.getQualityScore = function(): number {
  const { winRate, profitFactor, maxDrawdownPercentage, totalTrades } = this.metrics;
  
  // Trọng số cho từng thành phần
  const weights = {
    profitWeight: 0.3,
    winRateWeight: 0.2,
    profitFactorWeight: 0.2,
    drawdownWeight: 0.2,
    tradeCountWeight: 0.1
  };
  
  // Điểm cho mỗi thành phần (0-100)
  const profitScore = Math.min(this.profitPercentage * 2, 100);
  const winRateScore = winRate;
  const profitFactorScore = Math.min(profitFactor * 20, 100);
  const drawdownScore = Math.max(0, 100 - maxDrawdownPercentage * 2);
  const tradeCountScore = Math.min(totalTrades / 50 * 100, 100);
  
  // Tính điểm tổng thể
  const totalScore = (
    profitScore * weights.profitWeight +
    winRateScore * weights.winRateWeight +
    profitFactorScore * weights.profitFactorWeight +
    drawdownScore * weights.drawdownWeight +
    tradeCountScore * weights.tradeCountWeight
  );
  
  return Math.round(totalScore);
};

export const Backtest = mongoose.model<IBacktest>('Backtest', BacktestSchema); 