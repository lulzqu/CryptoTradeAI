import mongoose, { Schema, Document } from 'mongoose';

export interface ISignal extends Document {
  symbol: string;
  timeframe: string;
  direction: 'BUY' | 'SELL';
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  confidence: number;
  strategy: string;
  status: 'NEW' | 'TRIGGERED' | 'STOPPED' | 'COMPLETED' | 'EXPIRED';
  indicators: Record<string, any>;
  patterns: string[];
  expiryTime: Date;
  notes: string;
  createdBy: mongoose.Schema.Types.ObjectId;
  createdAt: Date;
  positions: mongoose.Schema.Types.ObjectId[];
}

const SignalSchema = new Schema<ISignal>(
  {
    symbol: {
      type: String,
      required: [true, 'Vui lòng nhập mã cặp giao dịch'],
      uppercase: true
    },
    timeframe: {
      type: String,
      required: [true, 'Vui lòng chọn khung thời gian'],
      enum: ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
    },
    direction: {
      type: String,
      required: [true, 'Vui lòng chọn hướng giao dịch'],
      enum: ['BUY', 'SELL']
    },
    entryPrice: {
      type: Number,
      required: [true, 'Vui lòng nhập giá vào lệnh']
    },
    stopLoss: {
      type: Number,
      required: [true, 'Vui lòng nhập mức Stop Loss']
    },
    takeProfit: {
      type: Number,
      required: [true, 'Vui lòng nhập mức Take Profit']
    },
    confidence: {
      type: Number,
      required: [true, 'Vui lòng nhập độ tin cậy'],
      min: [1, 'Độ tin cậy tối thiểu là 1%'],
      max: [100, 'Độ tin cậy tối đa là 100%']
    },
    strategy: {
      type: String,
      required: [true, 'Vui lòng nhập chiến lược']
    },
    status: {
      type: String,
      enum: ['NEW', 'TRIGGERED', 'STOPPED', 'COMPLETED', 'EXPIRED'],
      default: 'NEW'
    },
    indicators: {
      type: Schema.Types.Mixed,
      default: {}
    },
    patterns: {
      type: [String],
      default: []
    },
    expiryTime: {
      type: Date,
      required: [true, 'Vui lòng nhập thời gian hết hạn']
    },
    notes: {
      type: String,
      maxlength: [500, 'Ghi chú không được vượt quá 500 ký tự']
    },
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    positions: [{
      type: Schema.Types.ObjectId,
      ref: 'Position'
    }]
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Tính risk/reward ratio
SignalSchema.virtual('riskRewardRatio').get(function() {
  const risk = Math.abs(this.entryPrice - this.stopLoss);
  const reward = Math.abs(this.takeProfit - this.entryPrice);
  
  if (risk === 0) return 0;
  return (reward / risk).toFixed(2);
});

// Kiểm tra xem tín hiệu đã hết hạn chưa
SignalSchema.virtual('isExpired').get(function() {
  return new Date() > this.expiryTime;
});

// Hook để tự động cập nhật trạng thái khi tín hiệu hết hạn
SignalSchema.pre('save', async function(next) {
  // Kiểm tra nếu tín hiệu đã hết hạn và trạng thái vẫn là NEW
  if (new Date() > this.expiryTime && this.status === 'NEW') {
    this.status = 'EXPIRED';
  }
  
  next();
});

// Đếm số lượng vị thế đã tạo từ tín hiệu này
SignalSchema.virtual('positionCount').get(function() {
  return this.positions.length;
});

export const Signal = mongoose.model<ISignal>('Signal', SignalSchema); 