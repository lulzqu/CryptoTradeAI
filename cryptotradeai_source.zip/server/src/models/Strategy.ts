import mongoose, { Schema, Document } from 'mongoose';

export interface IStrategy extends Document {
  name: string;
  description: string;
  userId: mongoose.Schema.Types.ObjectId;
  isActive: boolean;
  isSystem: boolean;
  rules: {
    indicators: Array<{
      name: string;
      parameters: Record<string, any>;
      condition: string;
      value: any;
    }>;
    patterns: string[];
    timeframes: string[];
    markets: string[];
  };
  riskManagement: {
    maxRiskPerTrade: number;
    stopLossCalculation: string;
    takeProfitCalculation: string;
  };
  performance: {
    winRate: number;
    profitFactor: number;
    averageProfit: number;
    averageLoss: number;
    expectancy: number;
    tradingCount: number;
  };
  createdAt: Date;
  updatedAt: Date;
}

const StrategySchema = new Schema<IStrategy>(
  {
    name: {
      type: String,
      required: [true, 'Vui lòng nhập tên chiến lược'],
      trim: true,
      unique: true
    },
    description: {
      type: String,
      required: [true, 'Vui lòng nhập mô tả'],
      maxlength: [1000, 'Mô tả không được vượt quá 1000 ký tự']
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    isActive: {
      type: Boolean,
      default: true
    },
    isSystem: {
      type: Boolean,
      default: false
    },
    rules: {
      indicators: [{
        name: {
          type: String,
          required: true
        },
        parameters: {
          type: Schema.Types.Mixed,
          default: {}
        },
        condition: {
          type: String,
          required: true,
          enum: ['ABOVE', 'BELOW', 'CROSS_ABOVE', 'CROSS_BELOW', 'EQUALS', 'BETWEEN']
        },
        value: {
          type: Schema.Types.Mixed,
          required: true
        }
      }],
      patterns: [{
        type: String
      }],
      timeframes: [{
        type: String,
        enum: ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
      }],
      markets: [{
        type: String,
        uppercase: true
      }]
    },
    riskManagement: {
      maxRiskPerTrade: {
        type: Number,
        default: 1,
        min: 0.1,
        max: 10
      },
      stopLossCalculation: {
        type: String,
        enum: ['FIXED', 'ATR', 'SWING_LOW', 'PERCENTAGE'],
        default: 'PERCENTAGE'
      },
      takeProfitCalculation: {
        type: String,
        enum: ['FIXED', 'RISK_REWARD', 'FIBONACCI', 'PERCENTAGE'],
        default: 'RISK_REWARD'
      }
    },
    performance: {
      winRate: {
        type: Number,
        default: 0
      },
      profitFactor: {
        type: Number,
        default: 0
      },
      averageProfit: {
        type: Number,
        default: 0
      },
      averageLoss: {
        type: Number,
        default: 0
      },
      expectancy: {
        type: Number,
        default: 0
      },
      tradingCount: {
        type: Number,
        default: 0
      }
    }
  },
  {
    timestamps: true
  }
);

// Tính dự kiến lợi nhuận
StrategySchema.virtual('expectedReturn').get(function() {
  const { winRate, averageProfit, averageLoss } = this.performance;
  
  if (winRate === 0 || tradingCount === 0) return 0;
  
  const expectedReturn = (winRate / 100) * averageProfit - (1 - winRate / 100) * Math.abs(averageLoss);
  return parseFloat(expectedReturn.toFixed(2));
});

// Phương thức để cập nhật hiệu suất dựa trên kết quả giao dịch mới
StrategySchema.methods.updatePerformance = async function(
  isWin: boolean,
  profit: number
): Promise<void> {
  const { winRate, tradingCount, averageProfit, averageLoss, profitFactor } = this.performance;
  
  // Tính toán số thắng/thua mới
  const newTradingCount = tradingCount + 1;
  const oldWinCount = Math.round(tradingCount * (winRate / 100));
  const newWinCount = isWin ? oldWinCount + 1 : oldWinCount;
  const newWinRate = (newWinCount / newTradingCount) * 100;
  
  // Cập nhật lợi nhuận/lỗ trung bình
  if (isWin) {
    // Cập nhật lợi nhuận trung bình
    const newAverageProfit = (averageProfit * oldWinCount + profit) / newWinCount;
    this.performance.averageProfit = parseFloat(newAverageProfit.toFixed(2));
  } else {
    // Cập nhật lỗ trung bình
    const oldLossCount = tradingCount - oldWinCount;
    const newLossCount = newTradingCount - newWinCount;
    const newAverageLoss = (averageLoss * oldLossCount + Math.abs(profit)) / newLossCount;
    this.performance.averageLoss = parseFloat(newAverageLoss.toFixed(2));
  }
  
  // Cập nhật win rate và số giao dịch
  this.performance.winRate = parseFloat(newWinRate.toFixed(2));
  this.performance.tradingCount = newTradingCount;
  
  // Tính toán profit factor mới
  if (this.performance.averageLoss > 0) {
    this.performance.profitFactor = parseFloat(
      (this.performance.averageProfit / this.performance.averageLoss).toFixed(2)
    );
  }
  
  // Tính toán expectancy
  this.performance.expectancy = parseFloat(
    (this.performance.winRate / 100 * this.performance.profitFactor - (1 - this.performance.winRate / 100)).toFixed(2)
  );
  
  await this.save();
};

export const Strategy = mongoose.model<IStrategy>('Strategy', StrategySchema); 