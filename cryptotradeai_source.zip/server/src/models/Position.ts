import mongoose, { Document, Schema } from 'mongoose';

export interface IPosition extends Document {
  user: mongoose.Schema.Types.ObjectId;
  symbol: string;
  entryPrice: number;
  quantity: number;
  side: 'BUY' | 'SELL';
  leverage: number;
  status: 'OPEN' | 'CLOSED';
  takeProfitPrice: number;
  stopLossPrice: number;
  closingPrice?: number;
  profit?: number;
  openDate: Date;
  closeDate?: Date;
  strategy?: string;
  signalId?: mongoose.Schema.Types.ObjectId;
  notes?: string;
}

const PositionSchema = new Schema<IPosition>(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    symbol: {
      type: String,
      required: [true, 'Vui lòng nhập mã cặp giao dịch'],
      uppercase: true
    },
    entryPrice: {
      type: Number,
      required: [true, 'Vui lòng nhập giá vào lệnh']
    },
    quantity: {
      type: Number,
      required: [true, 'Vui lòng nhập số lượng']
    },
    side: {
      type: String,
      enum: ['BUY', 'SELL'],
      required: true
    },
    leverage: {
      type: Number,
      default: 1,
      min: 1
    },
    status: {
      type: String,
      enum: ['OPEN', 'CLOSED'],
      default: 'OPEN'
    },
    takeProfitPrice: {
      type: Number,
      required: true
    },
    stopLossPrice: {
      type: Number,
      required: true
    },
    closingPrice: {
      type: Number
    },
    profit: {
      type: Number
    },
    openDate: {
      type: Date,
      default: Date.now
    },
    closeDate: {
      type: Date
    },
    strategy: {
      type: String
    },
    signalId: {
      type: Schema.Types.ObjectId,
      ref: 'Signal'
    },
    notes: {
      type: String,
      maxlength: [500, 'Ghi chú không được vượt quá 500 ký tự']
    }
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Tính ROI (Return on Investment)
PositionSchema.virtual('roi').get(function() {
  if (this.status !== 'CLOSED' || !this.profit) {
    return null;
  }
  
  const investment = this.entryPrice * this.quantity;
  return ((this.profit / investment) * 100).toFixed(2);
});

// Tính duration (thời gian giữ vị thế)
PositionSchema.virtual('duration').get(function() {
  const endDate = this.closeDate || new Date();
  const durationMs = endDate.getTime() - this.openDate.getTime();
  const durationHours = Math.floor(durationMs / (1000 * 60 * 60));
  
  return durationHours;
});

// Pre-save hooks để tính profit khi đóng vị thế
PositionSchema.pre('save', async function(next) {
  if (this.isModified('status') && this.status === 'CLOSED' && this.closingPrice) {
    const entryValue = this.entryPrice * this.quantity;
    const exitValue = this.closingPrice * this.quantity;
    
    if (this.side === 'BUY') {
      this.profit = exitValue - entryValue;
    } else {
      this.profit = entryValue - exitValue;
    }
    
    // Nếu sử dụng đòn bẩy
    if (this.leverage > 1) {
      this.profit *= this.leverage;
    }
  }
  
  next();
});

export const Position = mongoose.model<IPosition>('Position', PositionSchema); 