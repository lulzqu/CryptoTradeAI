import express from 'express';
import {
  getUserSettings,
  updateUserSettings,
  getApiKeys,
  updateApiKeys,
  getNotificationSettings,
  updateNotificationSettings
} from '../controllers/settings.controller';
import { authenticate } from '../middleware/authenticate';

const router = express.Router();

// Tất cả routes yêu cầu xác thực
router.use(authenticate);

// Routes cho cài đặt người dùng
router.route('/user')
  .get(getUserSettings)
  .put(updateUserSettings);

// Routes cho API keys
router.route('/api-keys')
  .get(getApiKeys)
  .put(updateApiKeys);

// Routes cho thông báo
router.route('/notifications')
  .get(getNotificationSettings)
  .put(updateNotificationSettings);

export default router; 