import express from 'express';
import {
  getPositions,
  getPosition,
  createPosition,
  updatePosition,
  closePosition,
  deletePosition,
  getPortfolioStats,
  getTradeHistory
} from '../controllers/portfolio.controller';
import { authenticate } from '../middleware/authenticate';

const router = express.Router();

// Tất cả routes yêu cầu xác thực
router.use(authenticate);

// Routes cho positions
router.route('/positions')
  .get(getPositions)
  .post(createPosition);

router.route('/positions/:id')
  .get(getPosition)
  .put(updatePosition)
  .delete(deletePosition);

// Đóng vị thế
router.post('/positions/:id/close', closePosition);

// Thống kê danh mục đầu tư
router.get('/stats', getPortfolioStats);

// Lịch sử giao dịch
router.get('/history', getTradeHistory);

export default router; 