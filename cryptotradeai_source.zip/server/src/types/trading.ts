export interface Trade {
  id: string;
  userId: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  timestamp: Date;
  status: 'PENDING' | 'COMPLETED' | 'CANCELLED' | 'FAILED';
  fee: number;
  feeAsset: string;
  orderId: string;
  positionId?: string;
  signalId?: string;
}

export interface Position {
  id: string;
  userId: string;
  symbol: string;
  type: 'LONG' | 'SHORT';
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  leverage: number;
  margin: number;
  stopLoss: number;
  takeProfit: number;
  status: 'OPEN' | 'CLOSED' | 'LIQUIDATED';
  entryTime: Date;
  exitTime?: Date;
  exitPrice?: number;
  pnl?: number;
  pnlPercentage?: number;
  trades: string[];
  signalId?: string;
}

export interface Order {
  id: string;
  userId: string;
  symbol: string;
  type: 'MARKET' | 'LIMIT' | 'STOP_LOSS' | 'TAKE_PROFIT';
  side: 'BUY' | 'SELL';
  quantity: number;
  price?: number;
  stopPrice?: number;
  status: 'NEW' | 'PARTIALLY_FILLED' | 'FILLED' | 'CANCELLED' | 'REJECTED' | 'EXPIRED';
  timestamp: Date;
  positionId?: string;
  signalId?: string;
}

export interface Balance {
  asset: string;
  free: number;
  locked: number;
  total: number;
}

export interface TradingState {
  positions: Position[];
  orders: Order[];
  trades: Trade[];
  balance: Balance[];
  loading: boolean;
  error: string | null;
} 