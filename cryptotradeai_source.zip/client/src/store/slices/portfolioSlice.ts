import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { PortfolioState, Position, PositionStatus, SignalType } from '../../types';

// Initial state
const initialState: PortfolioState = {
  balance: 10000, // Starting with 10,000 USD
  availableMargin: 8000,
  usedMargin: 2000,
  positions: [],
  history: [],
  isLoading: false,
  error: null
};

// Async thunks
export const fetchPortfolio = createAsyncThunk(
  'portfolio/fetchPortfolio',
  async (_, { rejectWithValue }) => {
    try {
      // TODO: Replace with actual API call
      // Mock successful fetch
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Mock portfolio data
      const positions: Position[] = [
        {
          id: '1',
          symbol: 'SOL',
          type: SignalType.LONG,
          size: 2.0,
          entry: 120,
          current: 126,
          pnl: '+$120',
          pnlPercent: 5,
          stopLoss: 110,
          target: 140,
          timestamp: new Date().toISOString(),
          status: PositionStatus.OPEN
        },
        {
          id: '2',
          symbol: 'ETH',
          type: SignalType.SHORT,
          size: 0.5,
          entry: 2750,
          current: 2693,
          pnl: '+$28.5',
          pnlPercent: 2.1,
          stopLoss: 2850,
          target: 2500,
          timestamp: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
          status: PositionStatus.OPEN
        }
      ];
      
      const history: Position[] = [
        {
          id: '3',
          symbol: 'BTC',
          type: SignalType.LONG,
          size: 0.05,
          entry: 58000,
          current: 60000,
          pnl: '+$100',
          pnlPercent: 3.4,
          stopLoss: 56000,
          target: 62000,
          timestamp: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
          status: PositionStatus.CLOSED
        }
      ];
      
      return { 
        balance: initialState.balance,
        availableMargin: initialState.availableMargin,
        usedMargin: initialState.usedMargin,
        positions,
        history 
      };
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Không thể tải dữ liệu danh mục');
    }
  }
);

export const openPosition = createAsyncThunk(
  'portfolio/openPosition',
  async (position: Omit<Position, 'id' | 'current' | 'pnl' | 'pnlPercent' | 'timestamp' | 'status'>, { rejectWithValue }) => {
    try {
      // TODO: Replace with actual API call
      // Mock successful fetch
      await new Promise(resolve => setTimeout(resolve, 600));
      
      // Mock new position
      const newPosition: Position = {
        ...position,
        id: Math.random().toString(36).substring(2, 9),
        current: position.entry,
        pnl: '$0',
        pnlPercent: 0,
        timestamp: new Date().toISOString(),
        status: PositionStatus.OPEN
      };
      
      return newPosition;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Không thể mở vị thế');
    }
  }
);

export const closePosition = createAsyncThunk(
  'portfolio/closePosition',
  async (positionId: string, { rejectWithValue, getState }) => {
    try {
      // TODO: Replace with actual API call
      // Mock successful fetch
      await new Promise(resolve => setTimeout(resolve, 400));
      
      // Return the position ID
      return positionId;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Không thể đóng vị thế');
    }
  }
);

// Portfolio slice
const portfolioSlice = createSlice({
  name: 'portfolio',
  initialState,
  reducers: {
    updatePositionPrices: (state, action: PayloadAction<Record<string, number>>) => {
      // Update current prices for positions
      state.positions = state.positions.map(position => {
        if (action.payload[position.symbol]) {
          const currentPrice = action.payload[position.symbol];
          const priceDiff = position.type === SignalType.LONG 
            ? currentPrice - position.entry 
            : position.entry - currentPrice;
          const pnlValue = priceDiff * position.size;
          const pnlPercent = (priceDiff / position.entry) * 100;
          
          return {
            ...position,
            current: currentPrice,
            pnl: `${pnlValue >= 0 ? '+' : ''}$${Math.abs(pnlValue).toFixed(2)}`,
            pnlPercent: Number(pnlPercent.toFixed(2))
          };
        }
        return position;
      });
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch portfolio
      .addCase(fetchPortfolio.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchPortfolio.fulfilled, (state, action) => {
        state.isLoading = false;
        state.balance = action.payload.balance;
        state.availableMargin = action.payload.availableMargin;
        state.usedMargin = action.payload.usedMargin;
        state.positions = action.payload.positions;
        state.history = action.payload.history;
      })
      .addCase(fetchPortfolio.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string || 'Không thể tải dữ liệu danh mục';
      })
      
      // Open position
      .addCase(openPosition.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(openPosition.fulfilled, (state, action) => {
        state.isLoading = false;
        state.positions.push(action.payload);
        // Update margin values
        const positionValue = action.payload.size * action.payload.entry;
        state.usedMargin += positionValue;
        state.availableMargin -= positionValue;
      })
      .addCase(openPosition.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string || 'Không thể mở vị thế';
      })
      
      // Close position
      .addCase(closePosition.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(closePosition.fulfilled, (state, action) => {
        state.isLoading = false;
        // Find the position
        const position = state.positions.find(p => p.id === action.payload);
        
        if (position) {
          // Move to history with closed status
          state.history.push({
            ...position,
            status: PositionStatus.CLOSED
          });
          
          // Remove from active positions
          state.positions = state.positions.filter(p => p.id !== action.payload);
          
          // Update margin values
          const positionValue = position.size * position.entry;
          state.usedMargin -= positionValue;
          state.availableMargin += positionValue;
          
          // Update balance based on P&L
          const pnlValue = parseFloat(position.pnl.replace(/[+$]/g, '')) * (position.pnl.startsWith('+') ? 1 : -1);
          state.balance += pnlValue;
        }
      })
      .addCase(closePosition.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string || 'Không thể đóng vị thế';
      });
  }
});

export const { updatePositionPrices, clearError } = portfolioSlice.actions;

export default portfolioSlice.reducer; 