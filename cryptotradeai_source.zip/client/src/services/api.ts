import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { Signal, CandlestickPattern, CandlePattern, Strategy, BacktestResult } from '../types';

const api: AxiosInstance = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add a request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add a response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const apiService = {
  get: <T>(url: string, config?: AxiosRequestConfig): Promise<T> => 
    api.get<T>(url, config).then((res) => res.data),
  
  post: <T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => 
    api.post<T>(url, data, config).then((res) => res.data),
  
  put: <T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => 
    api.put<T>(url, data, config).then((res) => res.data),
  
  patch: <T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => 
    api.patch<T>(url, data, config).then((res) => res.data),
  
  delete: <T>(url: string, config?: AxiosRequestConfig): Promise<T> => 
    api.delete<T>(url, config).then((res) => res.data),
};

// API services cho từng module
export const authApi = {
  login: (email: string, password: string) => {
    return apiService.post<{ token: string }>('/auth/login', { email, password });
  },
  
  register: (userData: any) => {
    return apiService.post<{ token: string }>('/auth/register', userData);
  },
  
  forgotPassword: (email: string) => {
    return apiService.post('/auth/forgot-password', { email });
  },
  
  resetPassword: (token: string, password: string) => {
    return apiService.post('/auth/reset-password', { token, password });
  },
  
  verifyEmail: (token: string) => {
    return apiService.get(`/auth/verify-email/${token}`);
  },
  
  logout: () => {
    localStorage.removeItem('token');
    return Promise.resolve();
  }
};

export const userApi = {
  getProfile: () => {
    return apiService.get('/user/me');
  },
  
  updateProfile: (userData: any) => {
    return apiService.put('/user/me', userData);
  },
  
  updatePassword: (currentPassword: string, newPassword: string) => {
    return apiService.put('/user/password', { currentPassword, newPassword });
  },
  
  updateSettings: (settings: any) => {
    return apiService.put('/user/settings', settings);
  }
};

export const marketApi = {
  getMarketData: () => {
    return apiService.get('/market/data');
  },
  
  getSymbols: () => {
    return apiService.get<string[]>('/market/symbols');
  },
  
  getTicker: (symbol?: string) => {
    return apiService.get('/market/ticker', { params: { symbol } });
  },
  
  getTicker24h: (symbol?: string) => {
    return apiService.get('/market/ticker24h', { params: { symbol } });
  },
  
  getKlines: (symbol: string, interval: string = '1h', limit: number = 500) => {
    return apiService.get('/market/klines', { 
      params: { symbol, interval, limit } 
    });
  },
  
  getOrderBook: (symbol: string, limit: number = 100) => {
    return apiService.get('/market/orderbook', { 
      params: { symbol, limit } 
    });
  },
  
  getRecentTrades: (symbol: string, limit: number = 50) => {
    return apiService.get('/market/trades', { 
      params: { symbol, limit } 
    });
  },
  
  getFavorites: () => {
    return apiService.get<string[]>('/market/favorites');
  },
};

export const portfolioApi = {
  // Vị thế giao dịch
  getPositions: () => {
    return apiService.get('/portfolio/positions');
  },
  
  getPosition: (id: string) => {
    return apiService.get(`/portfolio/positions/${id}`);
  },
  
  createPosition: (positionData: any) => {
    return apiService.post('/portfolio/positions', positionData);
  },
  
  updatePosition: (id: string, positionData: any) => {
    return apiService.put(`/portfolio/positions/${id}`, positionData);
  },
  
  closePosition: (id: string, closeData: any) => {
    return apiService.put(`/portfolio/positions/${id}/close`, closeData);
  },
  
  // Thống kê
  getStats: () => {
    return apiService.get('/portfolio/stats');
  },
  
  // Lịch sử giao dịch
  getHistory: (limit: number = 50, page: number = 1) => {
    return apiService.get('/portfolio/history', { 
      params: { limit, page } 
    });
  },
  
  // Export dữ liệu
  exportData: (format: 'csv' | 'pdf', dateRange?: any) => {
    return apiService.get('/portfolio/export', { 
      params: { format, ...dateRange },
      responseType: 'blob'
    });
  }
};

export const analysisApi = {
  getTechnicalIndicators: (symbol: string, timeframe: string = '1d') => {
    return apiService.get('/analysis/indicators', { 
      params: { symbol, timeframe } 
    });
  },
  
  getTrendAnalysis: (symbol: string) => {
    return apiService.get('/analysis/trend', { 
      params: { symbol } 
    });
  },
  
  getPredictions: (symbol: string) => {
    return apiService.get('/analysis/predictions', { 
      params: { symbol } 
    });
  },
  
  getPatterns: (symbol: string, timeframe: string = '1d') => {
    return apiService.get<CandlestickPattern[]>('/analysis/patterns', { 
      params: { symbol, timeframe } 
    });
  },
  
  getSignals: (limit: number = 20, page: number = 1) => {
    return apiService.get<Signal[]>('/analysis/signals', { 
      params: { limit, page } 
    });
  },
  
  getSignal: (id: string) => {
    return apiService.get<Signal>(`/analysis/signals/${id}`);
  },
  
  updateSignal: (id: string, data: Partial<Signal>) => {
    return apiService.put<Signal>(`/analysis/signals/${id}`, data);
  },
  
  subscribeSignal: (id: string, subscribed: boolean) => {
    return apiService.post(`/analysis/signals/${id}/subscribe`, { subscribed });
  },
  
  deleteSignal: (id: string) => {
    return apiService.delete(`/analysis/signals/${id}`);
  },
  
  createCustomSignal: (signalData: Partial<Signal>) => {
    return apiService.post<Signal>('/analysis/signals/custom', signalData);
  }
};

export const settingsApi = {
  getSettings: () => {
    return apiService.get('/settings');
  },
  
  updateSettings: (settings: any) => {
    return apiService.put('/settings', settings);
  },
  
  getNotificationSettings: () => {
    return apiService.get('/settings/notifications');
  },
  
  updateNotificationSettings: (settings: any) => {
    return apiService.put('/settings/notifications', settings);
  },
  
  getTradingSettings: () => {
    return apiService.get('/settings/trading');
  },
  
  updateTradingSettings: (settings: any) => {
    return apiService.put('/settings/trading', settings);
  }
};

// Export tất cả các API service trong một object
const apiServices = {
  apiService,
  authApi,
  userApi,
  marketApi,
  portfolioApi,
  analysisApi,
  settingsApi
};

export default apiServices; 