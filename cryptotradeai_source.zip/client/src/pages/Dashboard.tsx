import React from 'react';
import { Row, Col, Card, Statistic, Table } from 'antd';
import {
  ArrowUpOutlined,
  ArrowDownOutlined,
  DollarOutlined,
  LineChartOutlined,
} from '@ant-design/icons';
import './Dashboard.css';

const Dashboard: React.FC = () => {
  const columns = [
    {
      title: 'Cặp tiền',
      dataIndex: 'pair',
      key: 'pair',
    },
    {
      title: 'Giá hiện tại',
      dataIndex: 'price',
      key: 'price',
    },
    {
      title: 'Thay đổi 24h',
      dataIndex: 'change',
      key: 'change',
      render: (value: number) => (
        <span style={{ color: value >= 0 ? '#52c41a' : '#f5222d' }}>
          {value >= 0 ? '+' : ''}{value}%
        </span>
      ),
    },
    {
      title: 'Khối lượng 24h',
      dataIndex: 'volume',
      key: 'volume',
    },
  ];

  const data = [
    {
      key: '1',
      pair: 'BTC/USDT',
      price: '$28,500',
      change: 2.5,
      volume: '$1.2B',
    },
    {
      key: '2',
      pair: 'ETH/USDT',
      price: '$1,800',
      change: -1.2,
      volume: '$800M',
    },
    {
      key: '3',
      pair: 'BNB/USDT',
      price: '$300',
      change: 0.8,
      volume: '$200M',
    },
  ];

  return (
    <div className="dashboard">
      <Row gutter={[24, 24]}>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Tổng tài sản"
              value={112893}
              precision={2}
              prefix={<DollarOutlined />}
              suffix="USD"
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Lợi nhuận 24h"
              value={2.5}
              precision={2}
              valueStyle={{ color: '#52c41a' }}
              prefix={<ArrowUpOutlined />}
              suffix="%"
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Tổng giao dịch"
              value={1128}
              prefix={<LineChartOutlined />}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Tỷ lệ thắng"
              value={75}
              precision={2}
              valueStyle={{ color: '#52c41a' }}
              suffix="%"
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={[24, 24]} style={{ marginTop: 24 }}>
        <Col span={24}>
          <Card title="Thị trường">
            <Table columns={columns} dataSource={data} pagination={false} />
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Dashboard; 