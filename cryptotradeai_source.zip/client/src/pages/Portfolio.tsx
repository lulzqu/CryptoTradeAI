import React from 'react';
import { Card, Row, Col, Statistic, Table, Tag, Progress } from 'antd';
import {
  ArrowUpOutlined,
  ArrowDownOutlined,
  DollarOutlined,
} from '@ant-design/icons';
import './Portfolio.css';

const Portfolio: React.FC = () => {
  const columns = [
    {
      title: 'Cặp tiền',
      dataIndex: 'pair',
      key: 'pair',
    },
    {
      title: 'Số lượng',
      dataIndex: 'amount',
      key: 'amount',
    },
    {
      title: 'Giá mua',
      dataIndex: 'buyPrice',
      key: 'buyPrice',
    },
    {
      title: 'Giá hiện tại',
      dataIndex: 'currentPrice',
      key: 'currentPrice',
    },
    {
      title: 'Lợi nhuận',
      dataIndex: 'profit',
      key: 'profit',
      render: (value: number) => (
        <Tag color={value >= 0 ? '#52c41a' : '#f5222d'}>
          {value >= 0 ? <ArrowUpOutlined /> : <ArrowDownOutlined />}
          {Math.abs(value)}%
        </Tag>
      ),
    },
    {
      title: 'Giá trị',
      dataIndex: 'value',
      key: 'value',
    },
  ];

  const data = [
    {
      key: '1',
      pair: 'BTC/USDT',
      amount: '0.5',
      buyPrice: '$28,000',
      currentPrice: '$30,000',
      profit: 7.14,
      value: '$15,000',
    },
    {
      key: '2',
      pair: 'ETH/USDT',
      amount: '10',
      buyPrice: '$1,800',
      currentPrice: '$1,700',
      profit: -5.56,
      value: '$17,000',
    },
    {
      key: '3',
      pair: 'BNB/USDT',
      amount: '50',
      buyPrice: '$300',
      currentPrice: '$320',
      profit: 6.67,
      value: '$16,000',
    },
  ];

  const allocationData = [
    {
      key: '1',
      asset: 'BTC',
      percentage: 40,
      color: '#1890ff',
    },
    {
      key: '2',
      asset: 'ETH',
      percentage: 30,
      color: '#52c41a',
    },
    {
      key: '3',
      asset: 'BNB',
      percentage: 30,
      color: '#faad14',
    },
  ];

  return (
    <div className="portfolio">
      <Row gutter={[24, 24]}>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Tổng giá trị"
              value={112893}
              precision={2}
              prefix={<DollarOutlined />}
              suffix="USD"
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Lợi nhuận 24h"
              value={2.5}
              precision={2}
              valueStyle={{ color: '#52c41a' }}
              prefix={<ArrowUpOutlined />}
              suffix="%"
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Lợi nhuận 7 ngày"
              value={5.8}
              precision={2}
              valueStyle={{ color: '#52c41a' }}
              prefix={<ArrowUpOutlined />}
              suffix="%"
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Lợi nhuận 30 ngày"
              value={12.3}
              precision={2}
              valueStyle={{ color: '#52c41a' }}
              prefix={<ArrowUpOutlined />}
              suffix="%"
            />
          </Card>
        </Col>

        <Col span={24}>
          <Card title="Phân bổ tài sản">
            <Row gutter={[24, 24]}>
              {allocationData.map((item) => (
                <Col xs={24} sm={12} lg={8} key={item.key}>
                  <div className="allocation-item">
                    <div className="allocation-header">
                      <span className="asset">{item.asset}</span>
                      <span className="percentage">{item.percentage}%</span>
                    </div>
                    <Progress
                      percent={item.percentage}
                      strokeColor={item.color}
                      showInfo={false}
                    />
                  </div>
                </Col>
              ))}
            </Row>
          </Card>
        </Col>

        <Col span={24}>
          <Card title="Danh mục đầu tư">
            <Table columns={columns} dataSource={data} pagination={false} />
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Portfolio; 